# Cowork Plugin Builder — Personal Skill

Add this personal skill to your Copilot Cowork so you can scaffold,
validate, and package Cowork plugins yourself (or render plugin
templates other people share with you).

Personal skills install per-user via OneDrive — **no tenant admin
approval needed**.

## What it does

- **Scaffold plugins from scratch**: builds manifest.json, SKILL.md,
  icons, and the upload-ready zip from your description.
- **Render plugin templates**: when you drop in a zip that contains
  `cowork-template.json`, Cowork prompts you for the declared
  variables (env label, MCP URL, OAuth referenceId, org info),
  substitutes the placeholders, generates a fresh manifest GUID, and
  produces a finished plugin zip ready to upload at M365 Admin Center
  → Agents → Upload custom app.

## Install — 2 minutes

### Option A — Via the `skills` skill in Cowork (recommended)

1. Open Copilot Cowork.
2. Say: **"add a personal skill from this zip"** and attach this
   package (`cowork-plugin-builder.personal-skill.zip`).
3. The `skills` skill will copy `cowork-plugin-builder/SKILL.md`
   into your OneDrive skill folder and validate it.
4. Cowork picks it up on the next turn — confirm by asking
   **"list my skills"** and looking for `cowork-plugin-builder`.

### Option B — Manual OneDrive copy

1. Extract this zip locally.
2. In OneDrive, open the Copilot Cowork skills folder
   (`Apps/Copilot Cowork/skills/` — exact path varies by tenant; if
   you're not sure, ask Cowork **"where do my personal skills
   live?"**).
3. Drop the entire `cowork-plugin-builder/` folder into that
   location, preserving the folder.
4. Refresh Cowork. The skill loads automatically.

## How to use it after install

### Build a plugin from scratch
> "Build me a Cowork plugin for [capability]" — Cowork will prompt
> for the connector type, env label, display name, trigger phrases,
> and developer info, then produce the zip.

### Render a plugin template someone shared with you
> Drop the template zip (must contain `cowork-template.json` at root)
> into Cowork and say **"use this template to build a plugin"**.
> Cowork detects the template, prompts you for each declared
> variable, substitutes placeholders, generates a fresh manifest
> GUID, and produces your final upload-ready zip.

## What's in this package

```
cowork-plugin-builder.personal-skill.zip
├── INSTALL.md                  (this file)
└── cowork-plugin-builder/
    └── SKILL.md                (the skill itself)
```

That's it. No external dependencies, no tenant admin approval, no
Power Platform connector to register.

## Author

Josh Cook · v1.2
