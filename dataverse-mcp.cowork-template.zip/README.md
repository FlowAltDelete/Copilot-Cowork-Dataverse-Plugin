# Dataverse MCP — Cowork Plugin Template

A reusable template that wraps any Microsoft Dataverse environment's
native MCP endpoint as a Copilot Cowork plugin. Each environment gets
its own plugin instance with env-scoped naming so users in the admin
center can tell them apart.

## How to use

### Option A — In Copilot Cowork (recommended)

1. Upload this `.zip` to Cowork and say "use this template to build a
   plugin". The `cowork-plugin-builder` skill will detect
   `cowork-template.json`, prompt you for each variable
   (env label, MCP URL, OAuth referenceId, org info), substitute the
   placeholders, generate a fresh manifest GUID, and produce a final
   `dataverse-<env_slug>.zip` ready to upload at M365 Admin Center →
   Agents → Upload custom app.

### Option B — Standalone (CLI)

Run the bundled `render.py` with a values file. The script reads
`cowork-template.json`, applies your values, and writes the rendered
plugin to a target folder.

```bash
python render.py --values my-env.json --out ./my-dataverse-plugin
```

`my-env.json` shape:

```json
{
  "env_label": "ContosoSales",
  "env_slug": "contososales",
  "mcp_server_url": "https://contososales.crm.dynamics.com/api/mcp",
  "oauth_reference_id": "<base64-vault-pointer>",
  "org_name": "Contoso",
  "org_slug": "contoso",
  "org_website": "https://www.contoso.com",
  "accent_color": "#0078D4"
}
```

## What's in this template

| Path | Purpose |
|------|---------|
| `cowork-template.json` | Variable declarations + file map + validation rules |
| `templates/manifest.json.tmpl` | Plugin manifest with `{{placeholder}}` values |
| `templates/skills/mcp-skill/SKILL.md.tmpl` | CRUD skill (read/search/create/update Dataverse rows) |
| `templates/skills/schema-skill/SKILL.md.tmpl` | Schema discovery skill (table + solution logical names) |
| `assets/color.png` | 192×192 plugin tile icon |
| `assets/outline.png` | 32×32 outline icon |
| `render.py` | Standalone renderer for CLI use |

## Variables you'll be prompted for

| Variable | What it is | Where to find it |
|----------|------------|------------------|
| `env_label` | Human-readable env name | Whatever you want to call it in the UI |
| `env_slug` | Lowercase slug | Auto-derived from label, you can override |
| `mcp_server_url` | Dataverse MCP endpoint | Power Platform admin center → your env → MCP endpoint (looks like `https://<env>.crm.dynamics.com/api/mcp`) |
| `oauth_reference_id` | Vault pointer for OAuth | Your Cowork admin generates it when registering the OAuth app in the tenant vault |
| `org_name`, `org_slug`, `org_website` | Publisher info | Your org / tenant |
| `accent_color` | Tile hex color | Optional; defaults to `#7B2CBF` |

## After upload

Cowork prompts each user to authenticate the OAuth app on first use.
Dataverse security roles enforce data access from there on.

## License

MIT
